<?php

$_['text_title']  = 'Anyday Split';
$_['payment_fee'] = 'Payment fee';