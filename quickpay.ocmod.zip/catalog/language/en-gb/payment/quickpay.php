<?php

$_['text_title']       = 'Credit Card';
$_['text_credit_card'] = 'Credit Card Details';
$_['payment_fee']      = 'Payment fee';