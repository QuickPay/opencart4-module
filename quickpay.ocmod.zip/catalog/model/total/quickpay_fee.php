<?php

namespace Opencart\Catalog\Model\Extension\QuickPay\Total;


class QuickPayFee extends \Opencart\System\Engine\Model {

	/**
	 * @param $total
	 */
	public function getTotal( $total ) {

	}
}