<?php
require_once DIR_EXTENSION . 'quickpay/autoload.php';

// Heading
$_['heading_title']           = QUICKPAY_NAME . ' MobilePay';
$_['text_quickpay_mobilepay'] = '<a target="_blank" href="' . QUICKPAY_LINK . '"><img style="height: 30px;" src="' . QUICKPAY_LOGO . '" alt="' . QUICKPAY_NAME . '" title="' . QUICKPAY_NAME . '" style="border: 1px solid #EEEEEE;" /></a>';