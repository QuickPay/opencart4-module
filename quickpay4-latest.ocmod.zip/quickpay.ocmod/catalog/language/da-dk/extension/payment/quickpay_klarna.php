<?php

$_['text_title']  = 'Klarna';
$_['payment_fee'] = 'Betalingsgebyr';